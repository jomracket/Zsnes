______________________________________________________________________

 ZSNES 8MB Build
 December 6, 2012
 Version 1.51 FuSoYa-8MB_R1

 FuSoYa's Niche
 http://fusoya.eludevisibility.org (also http://fusoya.cjb.net)
______________________________________________________________________

 CONTENTS
______________________________________________________________________

 1. Introduction
 2. What's New
 3. Legal Notice
 4. Contact Information

______________________________________________________________________

 1. Introduction
______________________________________________________________________


 This program is an unofficial build of ZSNES, to bring it a little
 more up to date with where Snes9x is in terms of supported ROM sizes.
 Previously ZSNES only supported up to 6MB and did not recognize
 ExLoROM, but this build adds 8MB support for ExHiROM, ExLoROM, SA-1,
 and SDD-1.

 This build also fixes an issue in ZSNES with SA-1 ROMs larger than
 4MB, where it would overwrite part of the loaded ROM data with the
 SA-1 RAM and some other table for character conversion DMA.

______________________________________________________________________

 2. What's New
______________________________________________________________________


Version 1.51 FuSoYa-8MB_R1 December 6, 2012

-First Release.

______________________________________________________________________

 3. Legal Notice
______________________________________________________________________

 This is an unofficial build of ZSNES.  You can find license
 information in the license.txt file of the docs folder.

______________________________________________________________________

 4. Contact Information
______________________________________________________________________

 FuSoYa
   www:   http://fusoya.eludevisibility.org (http://fusoya.cjb.net)
   ???:   06942508
______________________________________________________________________
